// Graphique en ligne (Performance Mensuelle)
var ctx1 = document.getElementById('lineChart').getContext('2d');
var lineChart = new Chart(ctx1, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'Performance',
            data: [10, 20, 15, 25, 35, 50, 45, 55, 60, 65, 70, 75],
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.2)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: {
        responsive: true
    }
});

// Graphique en camembert (Distribution des Thèmes)
var ctx2 = document.getElementById('pieChart').getContext('2d');
var pieChart = new Chart(ctx2, {
    type: 'pie',
    data: {
        labels: ['Intelligence Artificielle', 'Réalité Virtuelle', 'Cybersécurité', 'Autres'],
        datasets: [{
            data: [45, 25, 20, 10],
            backgroundColor: ['#7f8fa6', '#e74c3c', '#2ecc71', '#34495e']
        }]
    },
    options: {
        responsive: true
    }
});
